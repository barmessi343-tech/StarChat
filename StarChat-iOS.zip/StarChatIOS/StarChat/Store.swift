import SwiftUI

/// In-memory demo store. Swap for a TDLib-backed implementation to use real Telegram.
final class Store: ObservableObject {
    @Published var chats: [Chat] = Store.seedChats()
    @Published var nfts: [Nft] = Store.seedNfts()
    @Published var balance = 250
    @Published var transactions = [StarTx(title: "Welcome bonus", amount: 250)]

    private let replies = ["Nice! ⭐", "Haha, true", "Send me an NFT 😄", "On it", "Cool 🚀"]

    private func now() -> String {
        let f = DateFormatter()
        f.dateFormat = "HH:mm"
        return f.string(from: Date())
    }

    private func log(_ title: String, _ amount: Int) {
        transactions.insert(StarTx(title: title, amount: amount), at: 0)
    }

    func addMessage(chatId: Int, text: String, mine: Bool, gift: Nft? = nil) {
        guard let i = chats.firstIndex(where: { $0.id == chatId }) else { return }
        chats[i].messages.append(Message(text: text, mine: mine, time: now(), gift: gift))
    }

    func send(chatId: Int, text: String) {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        addMessage(chatId: chatId, text: t, mine: true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) { [weak self] in
            guard let self else { return }
            self.addMessage(chatId: chatId, text: self.replies.randomElement() ?? "👍", mine: false)
        }
    }

    func topUp(_ amount: Int) {
        balance += amount
        log("Top up (demo)", amount)
    }

    @discardableResult
    func buy(_ nftId: Int) -> Bool {
        guard let i = nfts.firstIndex(where: { $0.id == nftId }) else { return false }
        let n = nfts[i]
        guard !n.owned, !n.gifted, balance >= n.price else { return false }
        balance -= n.price
        nfts[i].owned = true
        log("Bought \(n.name)", -n.price)
        return true
    }

    @discardableResult
    func sendGift(chatId: Int, nftId: Int) -> Bool {
        guard let i = nfts.firstIndex(where: { $0.id == nftId }), nfts[i].owned else { return false }
        nfts[i].owned = false
        nfts[i].gifted = true
        addMessage(chatId: chatId, text: "", mine: true, gift: nfts[i])
        return true
    }

    private static func seedChats() -> [Chat] {
        [
            Chat(id: 1, title: "Alice", emoji: "🦊", color: Color(red: 0.49, green: 0.34, blue: 0.76),
                 messages: [Message(text: "Hey! Did you see the new NFT drop?", mine: false, time: "09:41")]),
            Chat(id: 2, title: "Dev Team", emoji: "💻", color: Color(red: 0.15, green: 0.65, blue: 0.60),
                 messages: [Message(text: "Build is green ✅", mine: false, time: "10:02")]),
            Chat(id: 3, title: "Crypto Club", emoji: "🚀", color: Color(red: 0.94, green: 0.42, blue: 0.0),
                 messages: [Message(text: "Legendary ones sell out fast ⭐", mine: false, time: "11:15")]),
            Chat(id: 4, title: "Saved", emoji: "⭐", color: Color(red: 0.12, green: 0.53, blue: 0.90),
                 messages: [Message(text: "Notes to self", mine: true, time: "08:00")]),
        ]
    }

    private static func seedNfts() -> [Nft] {
        [
            Nft(id: 1, name: "Pixel Fox", symbol: "🦊", price: 40, rarity: .common),
            Nft(id: 2, name: "Moon Cat", symbol: "🐱", price: 60, rarity: .common),
            Nft(id: 3, name: "Neon Skull", symbol: "💀", price: 120, rarity: .rare),
            Nft(id: 4, name: "Ice Crystal", symbol: "💎", price: 150, rarity: .rare),
            Nft(id: 5, name: "Cosmic Rocket", symbol: "🚀", price: 300, rarity: .epic),
            Nft(id: 6, name: "Dragon Egg", symbol: "🥚", price: 380, rarity: .epic),
            Nft(id: 7, name: "Golden Crown", symbol: "👑", price: 800, rarity: .legendary),
            Nft(id: 8, name: "Supernova", symbol: "🌟", price: 1000, rarity: .legendary),
        ]
    }
}
