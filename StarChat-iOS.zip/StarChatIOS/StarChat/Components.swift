import SwiftUI

extension Color {
    static let gold = Color(red: 1.0, green: 0.78, blue: 0.24)
    static let space0 = Color(red: 0.02, green: 0.03, blue: 0.06)
    static let space1 = Color(red: 0.07, green: 0.10, blue: 0.20)
    static let panel = Color(red: 0.09, green: 0.125, blue: 0.24)
    static let accentBlue = Color(red: 0.31, green: 0.64, blue: 1.0)
    static let muted = Color.white.opacity(0.6)
}

private struct Star {
    let x: CGFloat, y: CGFloat, r: CGFloat, phase: Double
    static func make(_ n: Int) -> [Star] {
        (0..<n).map { _ in
            Star(x: .random(in: 0...1), y: .random(in: 0...1), r: .random(in: 0.6...2.2), phase: .random(in: 0...6.28))
        }
    }
}

struct StarField: View {
    @State private var stars = Star.make(80)

    var body: some View {
        TimelineView(.animation) { timeline in
            Canvas { ctx, size in
                let t = timeline.date.timeIntervalSinceReferenceDate
                for s in stars {
                    let a = 0.25 + 0.75 * ((sin(t * 1.25 + s.phase) + 1) / 2)
                    let rect = CGRect(x: s.x * size.width - s.r, y: s.y * size.height - s.r, width: s.r * 2, height: s.r * 2)
                    ctx.fill(Path(ellipseIn: rect), with: .color(.white.opacity(a)))
                }
                let cycle = t.truncatingRemainder(dividingBy: 7) / 7
                if cycle < 0.2 {
                    let p = cycle / 0.2
                    let head = CGPoint(x: size.width * (0.9 - 0.5 * p), y: size.height * (0.05 + 0.3 * p))
                    let tail = CGPoint(x: head.x + 90, y: head.y - 45)
                    var path = Path()
                    path.move(to: head)
                    path.addLine(to: tail)
                    ctx.stroke(path, with: .linearGradient(Gradient(colors: [.white, .clear]), startPoint: head, endPoint: tail), lineWidth: 2)
                }
            }
        }
        .allowsHitTesting(false)
    }
}

struct SpaceBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.space0, Color.space1], startPoint: .top, endPoint: .bottom)
            StarField()
        }
        .ignoresSafeArea()
    }
}

extension View {
    func spaceBackground() -> some View { background(SpaceBackground()) }
}

struct StarShape: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let c = CGPoint(x: rect.midX, y: rect.midY)
        let outer = min(rect.width, rect.height) / 2
        let inner = outer * 0.45
        for i in 0..<10 {
            let r = i % 2 == 0 ? outer : inner
            let a = Double.pi / 5 * Double(i) - Double.pi / 2
            let pt = CGPoint(x: c.x + r * CGFloat(cos(a)), y: c.y + r * CGFloat(sin(a)))
            if i == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
        }
        p.closeSubpath()
        return p
    }
}

struct BigStar: View {
    @State private var pulse = false

    var body: some View {
        ZStack {
            Circle().fill(RadialGradient(colors: [Color.gold.opacity(0.35), .clear], center: .center, startRadius: 0, endRadius: 70))
            StarShape().fill(Color.gold).frame(width: 86, height: 86)
            StarShape().stroke(Color.white.opacity(0.6), lineWidth: 2).frame(width: 86, height: 86)
        }
        .frame(width: 140, height: 140)
        .scaleEffect(pulse ? 1.08 : 0.92)
        .onAppear {
            withAnimation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true)) { pulse = true }
        }
    }
}

struct BalanceChip: View {
    let amount: Int

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: "star.fill")
            Text("\(amount)").fontWeight(.bold).contentTransition(.numericText())
        }
        .foregroundColor(Color.gold)
        .padding(.horizontal, 12).padding(.vertical, 6)
        .background(Color.gold.opacity(0.2))
        .clipShape(Capsule())
        .animation(.easeOut(duration: 0.6), value: amount)
    }
}

struct Avatar: View {
    let emoji: String
    let color: Color
    var size: CGFloat = 46

    var body: some View {
        ZStack {
            Circle().fill(color)
            Text(emoji).font(.system(size: size * 0.48))
        }
        .frame(width: size, height: size)
    }
}
