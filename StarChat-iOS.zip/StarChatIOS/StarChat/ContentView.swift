import SwiftUI

struct ContentView: View {
    @StateObject private var store = Store()

    var body: some View {
        TabView {
            ChatListView()
                .tabItem { Label("Chats", systemImage: "bubble.left.and.bubble.right.fill") }
            StarsView()
                .tabItem { Label("Stars", systemImage: "star.fill") }
            NftView()
                .tabItem { Label("NFT", systemImage: "cube.fill") }
        }
        .environmentObject(store)
        .preferredColorScheme(.dark)
        .tint(Color.accentBlue)
    }
}
