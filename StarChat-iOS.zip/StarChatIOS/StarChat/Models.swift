import SwiftUI

enum Rarity: String {
    case common = "Common", rare = "Rare", epic = "Epic", legendary = "Legendary"

    var color: Color {
        switch self {
        case .common: return Color(red: 0.60, green: 0.65, blue: 0.69)
        case .rare: return Color(red: 0.31, green: 0.76, blue: 0.97)
        case .epic: return Color(red: 0.73, green: 0.41, blue: 0.78)
        case .legendary: return Color(red: 1.0, green: 0.84, blue: 0.31)
        }
    }
}

struct Nft: Identifiable, Hashable {
    let id: Int
    let name: String
    let symbol: String
    let price: Int
    let rarity: Rarity
    var owned = false
    var gifted = false
}

struct Message: Identifiable {
    let id = UUID()
    let text: String
    let mine: Bool
    let time: String
    var gift: Nft? = nil
}

struct Chat: Identifiable {
    let id: Int
    let title: String
    let emoji: String
    let color: Color
    var messages: [Message]
}

struct StarTx: Identifiable {
    let id = UUID()
    let title: String
    let amount: Int
}
