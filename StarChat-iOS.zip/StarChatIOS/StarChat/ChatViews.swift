import SwiftUI

struct ChatListView: View {
    @EnvironmentObject var store: Store

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: 6) {
                    ForEach(store.chats) { c in
                        NavigationLink(value: c.id) { row(c) }.buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16)
            }
            .navigationTitle("StarChat")
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { BalanceChip(amount: store.balance) } }
            .navigationDestination(for: Int.self) { ChatView(chatId: $0) }
            .spaceBackground()
        }
    }

    private func row(_ c: Chat) -> some View {
        let last = c.messages.last
        let preview = last?.gift.map { "🎁 NFT: \($0.name)" } ?? last?.text ?? ""
        return HStack(spacing: 12) {
            Avatar(emoji: c.emoji, color: c.color)
            VStack(alignment: .leading, spacing: 2) {
                Text(c.title).fontWeight(.semibold)
                Text(preview).lineLimit(1).font(.subheadline).foregroundColor(Color.muted)
            }
            Spacer()
            Text(last?.time ?? "").font(.caption).foregroundColor(Color.muted)
        }
        .padding(10)
        .contentShape(Rectangle())
    }
}

struct ChatView: View {
    let chatId: Int
    @EnvironmentObject var store: Store
    @State private var text = ""
    @State private var showGifts = false

    private var chat: Chat {
        store.chats.first { $0.id == chatId } ?? Chat(id: chatId, title: "", emoji: "", color: .gray, messages: [])
    }

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 8) {
                    ForEach(chat.messages) { MessageBubble(message: $0).id($0.id) }
                }
                .padding(12)
            }
            .onChange(of: chat.messages.count) { _ in
                if let last = chat.messages.last { withAnimation { proxy.scrollTo(last.id, anchor: .bottom) } }
            }
            .onAppear {
                if let last = chat.messages.last { proxy.scrollTo(last.id, anchor: .bottom) }
            }
        }
        .safeAreaInset(edge: .bottom) { inputBar }
        .navigationTitle(chat.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button { showGifts = true } label: { Text("🎁").font(.title2) }
            }
        }
        .sheet(isPresented: $showGifts) { GiftSheet(chatId: chatId) }
        .spaceBackground()
    }

    private var inputBar: some View {
        HStack(spacing: 8) {
            TextField("Message", text: $text, axis: .vertical)
                .lineLimit(1...4)
                .padding(10)
                .background(Color.panel)
                .clipShape(RoundedRectangle(cornerRadius: 20))
            Button {
                store.send(chatId: chatId, text: text)
                text = ""
            } label: {
                Image(systemName: "paperplane.fill").font(.title3)
            }
            .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
        .padding(8)
        .background(.ultraThinMaterial)
    }
}

struct MessageBubble: View {
    let message: Message

    var body: some View {
        HStack {
            if message.mine { Spacer(minLength: 40) }
            if let gift = message.gift {
                VStack(spacing: 4) {
                    Text(gift.symbol).font(.system(size: 56))
                    Text("NFT gift: \(gift.name)").fontWeight(.bold)
                    Text(gift.rarity.rawValue).font(.caption).foregroundColor(gift.rarity.color)
                    Text(message.time).font(.caption2).foregroundColor(Color.muted)
                }
                .padding(18)
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .fill(LinearGradient(colors: [gift.rarity.color.opacity(0.3), Color.panel], startPoint: .top, endPoint: .bottom))
                )
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(gift.rarity.color, lineWidth: 1))
            } else {
                VStack(alignment: .trailing, spacing: 2) {
                    Text(message.text)
                    Text(message.time).font(.caption2).foregroundColor(.white.opacity(0.55))
                }
                .padding(.horizontal, 12).padding(.vertical, 8)
                .background(message.mine ? Color.accentBlue.opacity(0.85) : Color.panel)
                .clipShape(RoundedRectangle(cornerRadius: 18))
            }
            if !message.mine { Spacer(minLength: 40) }
        }
    }
}

struct GiftSheet: View {
    let chatId: Int
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        let mine = store.nfts.filter { $0.owned }
        VStack(alignment: .leading, spacing: 10) {
            Text("Send an NFT gift").font(.headline)
            if mine.isEmpty {
                Text("You don't own any NFT yet. Buy one in the NFT tab.").foregroundColor(Color.muted)
            }
            ForEach(mine) { n in
                Button {
                    store.sendGift(chatId: chatId, nftId: n.id)
                    dismiss()
                } label: {
                    HStack(spacing: 12) {
                        Text(n.symbol).font(.system(size: 32))
                        VStack(alignment: .leading) {
                            Text(n.name).fontWeight(.semibold)
                            Text(n.rarity.rawValue).font(.caption).foregroundColor(n.rarity.color)
                        }
                        Spacer()
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
            Spacer()
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .presentationDetents([.medium])
    }
}
