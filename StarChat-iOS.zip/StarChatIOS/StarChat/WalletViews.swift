import SwiftUI

struct StarsView: View {
    @EnvironmentObject var store: Store

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 12) {
                    BigStar()
                    Text("\(store.balance)").font(.system(size: 44, weight: .bold)).foregroundColor(Color.gold)
                    Text("Your stars").foregroundColor(Color.muted)
                    HStack(spacing: 8) {
                        ForEach([50, 100, 500], id: \.self) { a in
                            Button("+\(a)") { store.topUp(a) }.buttonStyle(.borderedProminent)
                        }
                    }
                    Text("Demo top-up. Real payments need Apple In-App Purchase or Telegram's own Stars flow.")
                        .font(.caption).foregroundColor(Color.muted).multilineTextAlignment(.center)
                    Text("History").fontWeight(.bold).frame(maxWidth: .infinity, alignment: .leading).padding(.top, 8)
                    ForEach(store.transactions) { t in
                        HStack {
                            Text(t.title)
                            Spacer()
                            Text(t.amount > 0 ? "+\(t.amount)" : "\(t.amount)")
                                .fontWeight(.semibold)
                                .foregroundColor(t.amount > 0 ? Color(red: 0.42, green: 0.9, blue: 0.46) : Color(red: 1, green: 0.42, blue: 0.42))
                        }
                    }
                }
                .padding(16)
            }
            .navigationTitle("Stars")
            .navigationBarTitleDisplayMode(.inline)
            .spaceBackground()
        }
    }
}

struct NftView: View {
    @EnvironmentObject var store: Store
    @State private var tab = 0
    @State private var notEnough = false

    private var shown: [Nft] {
        tab == 0 ? store.nfts.filter { !$0.owned && !$0.gifted } : store.nfts.filter { $0.owned }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 12) {
                    Picker("", selection: $tab) {
                        Text("Market").tag(0)
                        Text("My collection").tag(1)
                    }
                    .pickerStyle(.segmented)
                    if shown.isEmpty {
                        Text(tab == 0 ? "Everything is sold out." : "Your collection is empty. Buy your first NFT.")
                            .foregroundColor(Color.muted)
                    }
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible())], spacing: 12) {
                        ForEach(shown) { n in
                            NftCard(nft: n, label: n.owned ? "Owned" : "Buy ⭐ \(n.price)", enabled: !n.owned) {
                                if !store.buy(n.id) { notEnough = true }
                            }
                        }
                    }
                }
                .padding(16)
            }
            .navigationTitle("NFT")
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { BalanceChip(amount: store.balance) } }
            .alert("Not enough stars", isPresented: $notEnough) { Button("OK", role: .cancel) {} }
            .spaceBackground()
        }
    }
}

struct NftCard: View {
    let nft: Nft
    let label: String
    let enabled: Bool
    let action: () -> Void
    @State private var glow = false

    var body: some View {
        let c = nft.rarity.color
        let borderOpacity = nft.rarity == .legendary ? (glow ? 1.0 : 0.4) : 0.8
        VStack(spacing: 4) {
            Text(nft.symbol).font(.system(size: 48))
            Text(nft.name).fontWeight(.bold).lineLimit(1)
            Text(nft.rarity.rawValue).font(.caption).foregroundColor(c)
            Button(action: action) { Text(label).font(.footnote) }
                .buttonStyle(.borderedProminent)
                .disabled(!enabled)
                .padding(.top, 8)
        }
        .padding(14)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(LinearGradient(colors: [c.opacity(0.28), Color.space1], startPoint: .top, endPoint: .bottom))
        )
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(c.opacity(borderOpacity), lineWidth: 1))
        .onAppear {
            withAnimation(.easeInOut(duration: 1.4).repeatForever(autoreverses: true)) { glow = true }
        }
    }
}
